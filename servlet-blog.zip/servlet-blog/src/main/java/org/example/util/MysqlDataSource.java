package org.example.util;

import javax.sql.DataSource;

public class MysqlDataSource implements DataSource {
}
